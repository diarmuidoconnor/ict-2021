fetch("https://randomuser.me/api/?results=10")
  .then(response => response.json())
  .then(json => {
    const contacts = json.results;
    const contactEmails = [];
    for (let i = 0; i < contacts.length; i++) {
      const entry = {
        name: `${contacts[i].name.first} ${contacts[i].name.last}`,
        email: contacts[i].email
      };
      contactEmails.push(entry);
    }
    // const contactEmails = contacts.map((contact, index, contacts) => {
    //   return {
    //     name: `${contact.name.first} ${contact.name.last}`,
    //     email: contact.email
    //   };
    // });
    console.log(contactEmails);
    console.log(contacts);
    // const contactAges = contacts.map(contact => contact.dob.age);
    // console.log(contactAges);
  })
  .catch(function(err) {
    console.log(err);
  });
