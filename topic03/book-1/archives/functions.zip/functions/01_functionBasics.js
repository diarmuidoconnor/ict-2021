const me = {
  name: {
    first: "Diarmuid",
    last: "O'Connor"
  },
  gender: "m"
};
const her = {
  name: {
    first: "Sheila",
    middle: "Yvonne",
    last: "Fleming"
  },
  gender: 'f'
};

const here = {
    name: 'Waterford',
    location: {
        long:  -7.11194,
        lat: 52.25833
    }
}

// ==================================

console.log("---- Function declarations --------");
function validatePerson(person) {
  return 'name' in person && 'gender' in person;
}

console.log(validatePerson(me));
console.log(validatePerson(here));

//=========================

console.log("---- Function expressions ----------");
const addMiddleName = function(person, middleName) {
  if ( person.name.middle === undefined) {
    person.name.middle = middleName;
  } else {
    person.name.middle += " " + middleName;
  }
};
addMiddleName(me, "Stephen");
addMiddleName(her, "Jane");
console.log(me.name);
console.log(her.name);

// ==================================

console.log("----- Arrow Function  --------");

const salute = (person) => {
  const title = person.gender === "m" ? "Mr" : "Ms";
  return title + " " + person.name.first + " " + person.name.last;
};

console.log(salute(me));

console.log("---- Shorthand Arrow Function  -------");

const hasMiddleName = person => person.name.middle !== undefined;

console.log(hasMiddleName(her));
