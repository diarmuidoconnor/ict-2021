var dogs = [
  {
    "name": "Dog 1",
    "address": "123 Test St",
    "phone_number": "132-3212"
  },
  {
    "name": "Dog 2",
    "address": "23 Main St",
    "phone_number": "934-4329"
  },
  {
    "name": "Dog 3",
    "address": "4 Lower St",
    "phone_number": "432-5832"
  },
  {
    "name": "Dog 4",
    "address": "49 Upper Street",
    "phone_number": "934-4290"
  }
];

export default dogs;
