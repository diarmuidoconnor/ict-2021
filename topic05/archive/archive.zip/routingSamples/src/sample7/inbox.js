import React from "react";
import { withRouter, Route } from "react-router-dom";
import { Messages } from "../sample4/inbox";

const BaseInbox = props => {
  return (
    <>
      <h2>Inbox page</h2>
      <Messages id={props.match.params.userId} />
      <Route
        path={`/inbox/:id/statistics`}
        render={props => {
          return <Stats {...props} usage={[5.4, 9.2]} />;
        }}
      />
      <Route path={`/inbox/:id/drafts`} component={Drafts} />
    </>
  );
};

const Stats = (props) => {
  return (
    <>
      <h3>Statistical data for user: {props.match.params.id}</h3>
      <h4>Emails sent (per day) = {props.usage[0]} </h4>
      <h4>Emails received (per day) = {props.usage[1]} </h4>
    </>
  );
};

const Drafts = (props) => {
  return <h3>Draft emails for user {props.match.params.id}</h3>;
};

export default withRouter(BaseInbox);
