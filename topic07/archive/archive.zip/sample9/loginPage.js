import React, { useState } from "react";
import { Redirect } from "react-router-dom";
import authenticator from "./authenticator";

const LoginPage = props => {
  const [loggedInStatue, setLoggedInStatus] = useState(false);
  // console.log(props.location)
  const login = () => {
    authenticator.authenticate("user1", "pass1", status =>
      setLoggedInStatus(status)
    );
  };
  const { from } = props.location.state || { from: { pathname: "/" } };
  if (loggedInStatue === true) {
    return <Redirect to={from} />;
  }
  return (
    <>
      <h2>Login page</h2>
      <p>You must log in to view the page at /protected </p>
      {/* Simple web form  */}
      <button onClick={login}>Log in</button>
    </>
  );
};

export default LoginPage;
