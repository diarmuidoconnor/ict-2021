import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Redirect, Switch, Link } from 'react-router-dom';
import {PublicPage, ProtectedPage, HomePage} from './pages'
import LoginPage from './loginPage'
import PrivateRoute from './privateRoute'
import AuthHeader from './authHeader'

const App = () => {
    return (
        <BrowserRouter>
         <div>
          <AuthHeader/>
            <ul>
              <li><Link to="/">Home</Link></li>
              <li><Link to="/public">Public</Link></li>
              <li><Link to="/protected">Protected</Link></li>
            </ul>
          <Switch>
              <Route path='/public' component={ PublicPage } />
              <Route path='/login' component={ LoginPage } />
              <Route exact path='/' component={ HomePage } />
              <PrivateRoute path='/protected' component={ ProtectedPage } />
              <Redirect from='*' to='/' />
          </Switch>
         </div>
      </BrowserRouter>
    ) 
}

ReactDOM.render(
    <App/>, 
    document.getElementById('root')) ;

