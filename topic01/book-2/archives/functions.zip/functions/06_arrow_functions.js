// New type of anonymous function

// Syntax supports two forms of function body:
//     - Block 
//     - Expression 

const array = [1, 2, 3, 4];
// ES5
let array2 = array.map(function (x) {
  return x * x;
});
console.log(`ES5 = ${array2}`);
// ES6 - arrow function with block body.
array2 = array.map((x) => {
  return x * x;
});
console.log(`block body = ${array2}`);
// ES6 - arrow function with expression body
array2 = array.map((x) => x * x);
console.log(`expression body = ${array2}`);

//=============================
// Use parentheses when their are multiple parameters
// (param1, param2, …, paramN) => { block }
// (param1, param2, …, paramN) => expression
// equivalent to:  => { return expression; }
const biggest = (a, b) => {
  if (a > b) return a;
  else return b;
  return false;
};
const biggerThan10 = a => a > 10 
console.log('\n')
console.log(` 3 v 5 ?  ${biggest(3, 5)}`);
console.log(` 5 > 10 ?  ${biggerThan10(5)}`);
array2 = array.map( x => x * x);
console.log(`Singlr parameter = ${array2}`);

//===============================
// To return an object, wrap it in parentheses
const objectResponse = value => ({ x: value });
console.log('\n')
console.log(objectResponse(10));
//=============================
// The 'this' context is automatically bound from the current lexical scope

const name = "Someone else";

const jane = {
  // Data
  name: "Jane Bloggs",
  address: "1 Main Street",
  // Methods
  saysHi: function() {
    console.log(`(Old function) Hi, I'm ${this.name}`);
  },
  saysArrowHi: () => {
    console.log(`(Arrow function) Hi, I'm ${this.name} `);
  },
  // Anonymous functions inside methods
  zoomInvite: function (friends) {
    friends.forEach(function (friend) {
      console.log(` ${this.name} sent invite to: ${friend}.`);
    }.bind(this));
  },
  zoomArrowInvite: function(friends) {
    friends.forEach((friend) => {
      console.log(` ${this.name} sent (arrow) invite to: ${friend}.`);
    });
  },
};
console.log('\n')
jane.saysHi();
jane.saysArrowHi();
console.log('\n')
jane.zoomInvite(["me", "you", "him", "her"]);
console.log('\n')
jane.zoomArrowInvite(["me", "you", "him", "her"]);

