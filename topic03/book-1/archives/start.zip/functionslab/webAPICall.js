fetch("https://jsonplaceholder.typicode.com/todos")
  .then(response => response.json())
  .then(json => {
    console.log(json);
    // const contacts = json.results;
    // contacts.forEach( contact => {
    //   console.log(contact)
    // });
  })
  .catch(function(err) {
    console.log(err);
  });
