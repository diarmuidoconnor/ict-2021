fetch("https://jsonplaceholder.typicode.com/todos")
  .then((response) => response.json())
  .then((json) => {
    const totalCompleted = json.reduce((acc, todo) => {
      acc += todo.completed ? 1 : 0;
      return acc
    }, 0);
    console.log(totalCompleted);
  })
  .catch(function (err) {
    console.log(err);
  });
