"use strict";

var rootElement = React.createElement(
  "div",
  {
    className: "pad"
  },
  React.createElement(
    "h1",
    {
      className: "heading"
    },
    "Languages"
  ),
  React.createElement(
    "ul",
    null,
    React.createElement("li", null, "Ruby"),
    React.createElement("li", null, "Javascript")
  )
);
ReactDOM.render(rootElement, document.getElementById("mount-point"));
