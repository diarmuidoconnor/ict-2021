fetch("https://randomuser.me/api/?results=10")
  .then(response => response.json())
  .then(json => {
    const contacts = json.results;
    const contactAges = contacts.map(contact => contact.dob.age);
    console.log(contactAges);
    // let ageAccumulation = 0;
    // for (let i = 0; i < contacts.length; i++) {
    //   ageAccumulation += contacts[i].dob.age;
    // }

    //  const ageAccumulation = contacts.reduce( (total, contact, index, array) => {
    //      return total + contact.dob.age
    //  }, 0)
    // console.log(ageAccumulation);

    // const youngest = contacts.reduce( (min, contact) => {
    //     const newMin = contact.dob.age < min ?  contact.dob.age : min
    //     console.log(newMin )
    //     return newMin
    // },100 )
    // console.log(youngest)

    // const ageGroups = {
    //   "25-": 0,
    //   "26-50": 0,
    //   "51-75": 0,
    //   "76+": 0
    // };

    // const ageCategories = Object.keys(ageGroups);
    // console.log(ageCategories);

    // const categorizByAge = age => {
    //   let ageCategory;
    //   if (age < 26) ageCategory = categories[0];
    //   else if (age < 51) ageCategory = ageCategories[1];
    //   else if (age < 76) ageCategory = ageCategories[2];
    //   else ageCategory = ageCategories[3];
    //   return ageCategory;
    // };
    // const contactsByAgeGroups = contacts.reduce((acc, contact) => {
    //   const key = categorizByAge(contact.dob.age);
    //   acc[key] += 1;
    //   return acc;
    // }, ageGroups);
    // console.log(contactsByAgeGroups);
  })
  .catch(function(err) {
    console.log(err);
  });
