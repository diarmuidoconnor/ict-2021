import React from "react";
import { withRouter } from "react-router-dom";

const BaseRegisterImperative = props => {
  const handleSubmit = user => {
    // save user to datastore
    props.history.push("/");
  };

  return (
    <>
      <h2>Registration Form</h2>
      <button onClick={handleSubmit}>Submit</button>
    </>
  );
};

export default withRouter(BaseRegisterImperative);
