import React, { useReducer, useEffect } from "react";
import FriendList from "./components/friendList";
import "./style.css";
import "../node_modules/bootstrap/dist/css/bootstrap.css";

const reducer = (state, action) => {
  switch (action.type) {
    case "confirmation":
      return {
        friends: state.friends.map((f) => {
          if (f.email === action.payload.friend.email) f.confirmed = true;
          return f;
        })
      };
    case "load-invitees":
      return {
        friends: action.payload.friends.map( f => {
          f.confirmed = false;
          return f
        })
      };
    case "cancellation":
      return {
        friends: state.friends.map((f) => {
          if (f.email === action.payload.friend.email) f.confirmed = false;
          return f;
        })
      };
    default:
      return state;
  }
};

const PartyApp = () => {
  const [state, dispatch] = useReducer(reducer, { friends: [] });

  useEffect(() => {
    fetch("https://randomuser.me/api/?results=10")
      .then((response) => response.json())
      .then((json) => {
        dispatch({ type: "load-invitees", payload: { friends: json.results } });
      });
  }, []);

  const confirmationReceived = (friend) => {
    dispatch({ type: "confirmation", payload: { friend: friend } });
  };

  const cancellationReceived = (friend) => {
    dispatch({ type: "cancellation", payload: { friend: friend } });
  };

  const attending = state.friends.filter((f) => f.confirmed);
  const absent = state.friends.filter((f) => !f.confirmed);

  return (
    <div className="jumbotron">
      <div className="container-fluid">
        <div className="row">
          <div className="col-6 offset-4">
            <h1>Zoom Party Manager</h1>
          </div>
        </div>
        <div className="row">
          <div className="col-6">
            <h2>Absent (Un-confirmed)</h2>
            <FriendList list={absent} action={confirmationReceived} />
          </div>
          <div className="col-6">
            <h2>Attending (Confirmed)</h2>
            <FriendList list={attending} action={cancellationReceived} />
          </div>
        </div>
      </div>
    </div>
  )
}

export default PartyApp;
