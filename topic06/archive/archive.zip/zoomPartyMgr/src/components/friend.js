import React from "react";

const Friend = ({friend, handler}) => {

  const onClick = (event) => {
    event.preventDefault();
    handler(friend);
  };
  return (
    <li>
      <button className="friend" type="button" onClick={onClick}>
        <h3>{` ${friend.name.first} ${friend.name.last}`}</h3>
      </button>
    </li>
  );
};

export default Friend;
