const rootElement = (
  <div className="pad">
    <h1 className="heading">Languages</h1>
    <ul>
      <li>Ruby</li>
      <li>Javascript</li>
    </ul>
  </div>
);

ReactDOM.render(rootElement, document.getElementById("mount-point"));
