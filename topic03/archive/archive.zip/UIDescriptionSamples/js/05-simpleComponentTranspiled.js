"use strict";

var DynamicLanguages = function DynamicLanguages() {
  return React.createElement(
    "div",
    {
      className: "pad"
    },
    React.createElement(
      "h1",
      {
        className: "heading"
      },
      "Dynamic Languages (Component)"
    ),
    React.createElement(
      "ul",
      null,
      React.createElement("li", null, "Python"),
      React.createElement("li", null, "Javascript")
    )
  );
};

ReactDOM.render(
  React.createElement(DynamicLanguages, null),
  document.getElementById("mount-point")
);
