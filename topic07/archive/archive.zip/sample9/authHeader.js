import React from "react";
import authenticator from "./authenticator";
import { withRouter } from "react-router-dom";

const BaseAuthHeader = props => {
  const { history } = props;
  const signOutHandler = () => authenticator.signout(() => history.push("/"));
  return authenticator.isAuthenticated ? (
    <p>
      Welcome! <button onClick={signOutHandler}>Sign out</button>
    </p>
  ) : (
    <p>
      You are not logged in{" "}
      <button onClick={() => history.push("/login")}>Login</button>
    </p>
  );
};
export default withRouter(BaseAuthHeader);
