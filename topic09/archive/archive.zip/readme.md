# EWD 2021

Enterprise Web Dev examples from lectures. Please run ``npm install`` before using.

To run an example, type ``npx babel-node script.js``