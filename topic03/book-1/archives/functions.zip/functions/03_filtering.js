fetch("https://randomuser.me/api/?results=10")
  .then(response => response.json())
  .then(json => {
    const contacts = json.results;
    const femaleContacts = [];
    for (let i = 0; i < contacts.length; i++) {
      if (contacts[i].gender === "female") {
        femaleContacts.push(contacts[i]);
      }
    }
    // const femaleContacts = contacts.filter((contact, index, contacts) => {
    //   console.log(`${index} - ${contact.gender} `);
    //   return contact.gender === "female";
    // });
    console.log(femaleContacts);
    console.log(contacts);
    // const under40Males = contacts.filter(
    //   contact => contact.gender === "male" && contact.dob.age < 40
    // );
    // console.log(under40Males);
  })
  .catch(function(err) {
    console.log(err);
  });
